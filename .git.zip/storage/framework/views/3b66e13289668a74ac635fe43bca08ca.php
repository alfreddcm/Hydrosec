<link href="<?php echo e(asset('css/owner/workeraccount.css')); ?>" rel="stylesheet">
<?php $__env->startSection('title', 'Worker Account'); ?>
<?php $__env->startSection('content'); ?>

    <?php
        use Illuminate\Support\Facades\DB;
        use Illuminate\Support\Facades\Crypt;
        use App\Models\Owner;
        use App\Models\Admin;
        use App\Models\Worker;

        $accs = DB::table('tbl_workeraccounts')
            ->join('tbl_tower', 'tbl_workeraccounts.OwnerID', '=', 'tbl_tower.OwnerID')
            ->where('tbl_workeraccounts.OwnerID', Auth::id())
            ->select('tbl_workeraccounts.*', 'tbl_tower.name as tower_name', 'tbl_tower.name as towerid')
            ->get();
        $counter = 1;

    ?>
    <div class="container">
        <div class="row text-start">
            <div id="wrapper">
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                <nav>
                    <div id="page-wrapper">
                        <div class="row">
                            <div class="col-lg-12">
                                <h4 class="page-header"></h4>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="panel-heading">
                                    Owner Worker Accounts List
                                </div>

                                <div class="panel-body">
                                    <div class="dataTable_wrapper">
                                        <!-- Active Accounts Table -->
                                        <h3>Active Accounts</h3>
                                        <table class="table table-striped table-bordered table-hover"
                                            id="dataTables-example-active">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Name</th>
                                                    <th>Username</th>
                                                    <th>Tower</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $accs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(Crypt::decryptString($user->status) == '1'): ?>
                                                        <tr class="odd gradeX">
                                                            <td><?php echo e($loop->iteration); ?></td>
                                                            <td><?php echo e(Crypt::decryptString($user->name)); ?></td>
                                                            <td><?php echo e(Crypt::decryptString($user->username)); ?></td>
                                                            <td><?php echo e(Crypt::decryptString($user->tower_name)); ?></td>
                                                            <td>
                                                                <div class="btn-group">
                                                                    <a href="<?php echo e(route('ownerworker.edit', $user->id)); ?>"c1
                                                                        class="btn btn-primary btn-rounded">Edit</a>
                                                                    <form action="<?php echo e(route('ownerworker.dis', $user->id)); ?>"
                                                                        method="POST">
                                                                        <?php echo csrf_field(); ?>
                                                                        <button
                                                                            onclick="return confirm('Are you sure you want to delete this?')"
                                                                            type="submit"
                                                                            class="btn btn-danger btn-rounded">
                                                                            Disable
                                                                        </button>
                                                                    </form>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>

                                        <!-- Disabled Accounts Table -->
                                        <h3>Disabled Accounts</h3>
                                        <table class="table table-striped table-bordered table-hover"
                                            id="dataTables-example-disabled">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Name</th>
                                                    <th>Username</th>
                                                    <th>Tower</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $accs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(Crypt::decryptString($user->status) == '0'): ?>
                                                        <tr class="odd gradeX">
                                                            <td><?php echo e($loop->iteration); ?></td>
                                                            <td><?php echo e(Crypt::decryptString($user->name)); ?></td>
                                                            <td><?php echo e(Crypt::decryptString($user->username)); ?></td>
                                                            <td><?php echo e(Crypt::decryptString($user->tower_name)); ?></td>
                                                            <td>
                                                                <div class="btn-group">
                                                                    <form action="<?php echo e(route('ownerworker.en', $user->id)); ?>"
                                                                        method="POST">
                                                                        <?php echo csrf_field(); ?>
                                                                        <button
                                                                            onclick="return confirm('Are you sure you want to enable this?')"
                                                                            type="submit"
                                                                            class="btn btn-secondary ti-trash btn-rounded">
                                                                            Enable
                                                                        </button>
                                                                    </form>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>

            </div>
        </div>
        <a href="<?php echo e(route('addworker')); ?>" class="btn btn-success mt-1">
            Add Worker Account
        </a>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Owner/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\Cap\Hydrosec\resources\views/Owner/WorkerAccounts.blade.php ENDPATH**/ ?>