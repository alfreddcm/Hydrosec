<?php $__env->startSection('title', 'Edit User'); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div id="wrapper">
        <nav>
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h4 class="page-header">Edit User</h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Edit User
                            </div>
                            <div class="panel-body">
                                <form action="<?php echo e(route('admin.update', $user->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="name">Name:</label>
                                        <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="name">Username:</label>
                                        <input type="text" class="form-control" name="username" value="<?php echo e($user->username); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Email:</label>
                                        <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>" required>
                                    </div>
                                    <a href="javascript:void(0);" onclick="openPasswordModal(<?php echo e($user->id); ?>)" class="btn btn-success">Update Password</a>
                                    <button type="submit" class="btn btn-primary">Update</button>
                                    <a href="<?php echo e(route('UserAccounts')); ?>" class="btn btn-secondary">Cancel</a>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </div>
</div>

<div class="modal fade" id="passwordModal" tabindex="-1" role="dialog" aria-labelledby="passwordModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="passwordModalLabel">Update Password</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form id="passwordForm" action="<?php echo e(route('admin.updatePassword', ['id' => $user->id])); ?>" method="post">
      <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="password">New Password</label>
            <input type="password" class="form-control" id="password" name="password" required>
          </div>
          <div class="form-group">
            <label for="password_confirmation">Confirm Password</label>
            <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" required>
          </div>
          <input type="hidden" id="userId">
          <button type="submit" class="btn btn-primary">Update</button>
        </form>
      </div>
    </div>
  </div>
</div>

</div>
<script>
    function openPasswordModal(userId) {
        $('#userId').val(userId);
        $('#passwordModal').modal('show');
    }

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\Cap\Hydrosec\resources\views/Admin/edit.blade.php ENDPATH**/ ?>