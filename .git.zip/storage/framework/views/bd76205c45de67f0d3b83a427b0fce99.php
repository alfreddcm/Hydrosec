<!doctype html>
<html lang="en">

<head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link href="<?php echo e(asset('css/sidebar.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.0.0/dist/chartjs-plugin-datalabels.min.js"></script>
    <link href="<?php echo e(asset('css/worker/dashboard.css')); ?>" rel="stylesheet">
</head>

<body>
    <main class="container">
        <div class="row g-0">
            <div class="col-2 side">
                <div class="p-2 text-white">
                    <a
                        href="#"class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                        <img src="" alt="logo">
                        <span class="fs-4">
                            <div class="dropdown ps-1">
                                <a href="#"
                                    class="d-flex align-items-center text-white text-decoration-none dropdown-toggle"
                                    id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">

                                    <strong>
                                        <?php
                                            use Illuminate\Support\Facades\Crypt;

                                            if (Auth::check()) {
                                                $decryptedName = Crypt::decryptString(Auth::user()->name);
                                            }

                                        ?>
                                        <p><?php echo e($decryptedName); ?></p>
                                    </strong>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-dark text-small shadow"
                                    aria-labelledby="dropdownUser1">
                                    
                                    <li>
                                        <hr class="dropdown-divider">
                                    </li>
                                    <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Sign out</a></li>
                                </ul>
                            </div>
                        </span>
                    </a>
                    <hr>
                    <ul class="nav nav-pills flex-column mb-auto">
                        <li class="nav-item">
                            <a href="/Worker/dashboard"
                                class="nav-link <?php echo e(request()->is('Owner/dashboard') ? 'active' : 'text-white'); ?>"
                                aria-current="page">
                                <svg class="bi me-2" width="16" height="16">
                                    <use xlink:href="#home"></use>
                                </svg>
                                Dashboard
                            </a>
                        </li>
                        
                    </ul>
                </div>

            </div>
            <div class="col main">
                <div class="dashboard-header mb-2">
                    <div class="row">
                        <div class="col">
                            <h2><?php echo $__env->yieldContent('title'); ?></h2>
                        </div>
                        <div class="col text-end ">
                            <p><?php echo e(\Carbon\Carbon::now()->format('D | M d, Y')); ?></p>
                        </div>
                    </div>
                </div>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
    </main>

    <script src="https://www.google.com/recaptcha/api.js" async defer></script>

    <!-- Bootstrap JavaScript Libraries -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sweetalert.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\Users\User\Desktop\Cap\Hydrosec\resources\views/Worker/header.blade.php ENDPATH**/ ?>