<?php $__env->startComponent('mail::message'); ?>

Hello!

You have received an OTP: <?php echo e($otpcode); ?>


If you did not create an account, no further action is required.


Thanks,<br>
<?php echo e(config('app.name')); ?>


<?php $__env->slot('footer'); ?>
<?php $__env->startComponent('mail::footer'); ?>
<?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?>. <?php echo app('translator')->get('All Rights Reserved.'); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\User\Desktop\Cap\Hydrosec\resources\views/mailotp.blade.php ENDPATH**/ ?>