<link href="<?php echo e(asset('css/owner/managetower.css')); ?>" rel="stylesheet">
<?php $__env->startSection('title', 'Manage Tower'); ?>
<?php $__env->startSection('content'); ?>
    <?php
        use Illuminate\Support\Facades\Auth;
        use App\Models\Tower;
        use App\Models\Owner;

        $towers = Tower::where('OwnerID', Auth::id())->get();

    ?>
    <style>
        .addtowerb {
            position: absolute;
            bottom: 20px;
            right: 20px;
        }

        .addtowerbutton {
            position: sticky;
        }

        a {
            text-decoration: none;
        }

        .card {
            text-transform: uppercase;
        }

        .card {
            border-radius: 10px;
            transition: transform 0.2s ease-in-out;
        }

        .card:hover {
            transform: scale(1.02);
        }

        .card-title {
            letter-spacing: 1px;
        }

        .card-text span.font-weight-bold {
            font-size: 1.1em;
        }

        .badge {
            font-size: 1em;
            padding: 5px 10px;
            color: #000;
        }

        .card-body img {
            height: 100px;
        }

        .no-line-spacing {
            margin-bottom: 0;
            padding-bottom: 0;
        }
    </style>
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="row">
                    <h4>Tower List:</h4>
                    <?php if($towers->isNotEmpty()): ?>
                        <?php $__currentLoopData = $towers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $decryptedStatus = Crypt::decryptString($data->status);
                            ?>
                    
                            <?php if($decryptedStatus == '0' || $decryptedStatus == '1'): ?>
                                <div class="col-sm-3">
                                    <a href="<?php echo e(route('towerdata', ['id' => $data->id])); ?>">
                                        <div class="card shadow-sm mb-4 border-0">
                                            <div class="card-body">
                                                <div class="row g-0 mr-0">
                                                    <div class="col-sm-4">
                                                        <img src="<?php echo e(asset('images/icon/towericon.png')); ?>" alt="towericon">
                                                    </div>
                                                    <div class="col">
                                                        <h5 class="card-title text-uppercase text-primary">
                                                            <b><?php echo e($data->id); ?> <?php echo e(Crypt::decryptString($data->name)); ?></b>
                                                        </h5>
                                                        <p class="card-text">
                                                            <span class="text-muted">Code:</span> 
                                                            <span class="font-weight-bold"><?php echo e(Crypt::decryptString($data->towercode)); ?></span>
                                                        </p>
                                                        <p class="card-text">
                                                            <b>Status:</b>
                                                            <span class="badge">
                                                                <?php echo e($decryptedStatus == '1' ? 'Active' : 'Pending'); ?>

                                                            </span>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            <?php elseif($decryptedStatus == '4'): ?>
                                <!-- Display card for towers ready for harvesting -->
                                <div class="col-sm-3">
                                    <div class="card shadow-sm mb-1 border-0">
                                        <div class="card-body">
                                            <a href="">

                                                <h5 class="card-title text-uppercase text-success">
                                                Tower <?php echo e(Crypt::decryptString($data->name)); ?> ready for harvesting!
                                                <p class="card-text">
                                                    <span class="text-muted">Code:</span> 
                                                    <span class="font-weight-bold"><?php echo e(Crypt::decryptString($data->towercode)); ?></span>
                                                </p>
                                                <center>
                                                    <form action="<?php echo e(route('tower.restart')); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="tower_id" value="<?php echo e($data->id); ?>">
                                                    <button type="submit" class="btn btn-primary mb-1">Restart</button>
                                                </form>
                                                </center>
                                                
                                                
                                            </h5>
                                            </a>
                                            
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <span>No towers</span>
                    <?php endif; ?>
                    


                </div>
                <div class="addtowerb">
                    <a href="#" class="btn btn-success mt-1 addtowerbutton" data-bs-toggle="modal"
                        data-bs-target="#addTowerModal">
                        Add Tower
                    </a>
                </div>

            </div>
        </div>
    </div>



    <!-- Bootstrap Modal -->
    <div class="modal fade" id="addTowerModal" tabindex="-1" aria-labelledby="addTowerModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addTowerModalLabel">Add Tower</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('posttower')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="towercode" class="form-label">Tower Name</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="towercode" class="form-label">Tower Code</label>
                            <input type="text" class="form-control" id="towercode" name="towercode" required>
                        </div>

                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    


    <script>
    
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Owner/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\Cap\Hydrosec\resources\views/Owner/ManageTower.blade.php ENDPATH**/ ?>